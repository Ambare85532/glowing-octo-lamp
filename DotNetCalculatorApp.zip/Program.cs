using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Hosting;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

app.MapGet("/", () => "Welcome to Calculator App!");
app.MapGet("/add", (int a, int b) => $"Result: {a + b}");
app.MapGet("/subtract", (int a, int b) => $"Result: {a - b}");
app.MapGet("/multiply", (int a, int b) => $"Result: {a * b}");
app.MapGet("/divide", (int a, int b) => b != 0 ? $"Result: {a / b}" : "Cannot divide by zero");

app.Run();